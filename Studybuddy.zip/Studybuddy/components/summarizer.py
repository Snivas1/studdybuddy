import streamlit as st
from utils.llm import ask_ai
from utils.prompts import summarize_prompt

def show_summarizer():
    st.header("📝 Notes Summarizer")

    text = st.text_area("Paste your notes here")

    if st.button("Summarize"):
        with st.spinner("Summarizing..."):
            response = ask_ai(summarize_prompt(text))
            st.write(response)