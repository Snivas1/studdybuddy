import streamlit as st
from utils.llm import ask_ai
from utils.prompts import explain_prompt

def show_explainer():
    st.header("📖 Concept Explainer")

    topic = st.text_input("Enter Topic")
    level = st.selectbox("Select Level", ["Beginner", "Intermediate", "Advanced"])

    if st.button("Explain"):
        with st.spinner("Generating explanation..."):
            response = ask_ai(explain_prompt(topic, level))
            st.write(response)