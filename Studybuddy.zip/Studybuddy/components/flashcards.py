import streamlit as st
import json
from utils.llm import ask_ai
from utils.prompts import flashcard_prompt

def show_flashcards():
    st.header("🃏 Flashcard Generator")

    topic = st.text_input("Enter Topic for Flashcards")

    # ✅ Add number selector
    num_cards = st.number_input(
        "How many flashcards?",
        min_value=1,
        max_value=20,
        value=5
    )

    if st.button("Generate Flashcards"):
        if topic.strip() == "":
            st.warning("Please enter a topic.")
            return

        with st.spinner("Generating flashcards..."):
            response = ask_ai(
                flashcard_prompt(topic, num_cards)
            )

            try:
                flashcards = json.loads(response)

                for i, card in enumerate(flashcards):
                    st.markdown(f"### Card {i+1}")
                    st.write(f"**Q:** {card['question']}")
                    st.write(f"**A:** {card['answer']}")
                    st.markdown("---")

            except:
                st.error("Failed to generate flashcards. Try again.")