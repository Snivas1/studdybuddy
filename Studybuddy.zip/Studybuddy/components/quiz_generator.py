import streamlit as st
import json
from utils.llm import ask_ai
from utils.prompts import quiz_prompt
def show_quiz():
    st.header("🧠 Interactive Quiz Generator")

    topic = st.text_input("Enter Topic for Quiz")

    num_questions = st.number_input(
        "How many questions?",
        min_value=1,
        max_value=15,
        value=5
    )

    # ✅ ADD THIS (Difficulty Selector)
    difficulty = st.selectbox(
        "Select Difficulty",
        ["Easy", "Medium", "Hard"]
    )

    if st.button("Generate Quiz"):
        with st.spinner("Generating quiz..."):
            response = ask_ai(
                quiz_prompt(topic, num_questions, difficulty)
            )

            try:
                quiz_data = json.loads(response)
                st.session_state.quiz = quiz_data
            except:
                st.error("Failed to generate quiz. Try again.")
                return

    if "quiz" in st.session_state:

        user_answers = []

        for i, q in enumerate(st.session_state.quiz):
            st.subheader(f"Q{i+1}. {q['question']}")

            selected = st.radio(
                "Choose an option:",
                q["options"],
                key=f"q{i}",
                index=None
            )

            user_answers.append(selected)

        if st.button("Submit Quiz"):
            score = 0

            for i, q in enumerate(st.session_state.quiz):
                if user_answers[i] == q["answer"]:
                    score += 1

            st.markdown("---")
            st.subheader(f"🎯 Your Score: {score} / {len(st.session_state.quiz)}")

            for i, q in enumerate(st.session_state.quiz):
                if user_answers[i] == q["answer"]:
                    st.success(f"Q{i+1}: Correct ✅")
                else:
                    st.error(f"Q{i+1}: Wrong ❌")
                    st.info(f"Correct Answer: {q['answer']}")