def explain_prompt(topic, level):
    return f"""
Explain the topic "{topic}" at a {level} level.

Requirements:
- Use simple and clear language.
- Provide real-world examples.
- Break explanation into short paragraphs.
- Highlight important terms if needed.
"""


def summarize_prompt(text):
    return f"""
Summarize the following content into clear bullet points.

Requirements:
- Focus on key ideas.
- Remove unnecessary details.
- Keep it concise and structured.

Content:
{text}
"""


def quiz_prompt(topic, num_questions, difficulty):
    return f"""
Generate {num_questions} multiple choice questions about "{topic}".
Difficulty level: {difficulty}.

Return response ONLY in this strict JSON format:

[
  {{
    "question": "Question text",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "answer": "Exact correct option text"
  }}
]

Rules:
- Exactly 4 options per question.
- The correct answer must exactly match one of the options.
- Do NOT include explanations.
- Do NOT include numbering outside JSON.
- Do NOT wrap response in markdown.
- Return ONLY valid JSON.
"""


def flashcard_prompt(topic, num_cards):
    return f"""
Generate {num_cards} flashcards about "{topic}".

Return response ONLY in this JSON format:

[
  {{
    "question": "Flashcard question",
    "answer": "Concise answer"
  }}
]

Rules:
- Keep answers short and clear.
- Do NOT add extra text.
- Return ONLY valid JSON.
"""